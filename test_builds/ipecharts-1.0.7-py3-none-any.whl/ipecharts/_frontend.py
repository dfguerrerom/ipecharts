"""
Information about the frontend package of the widgets.
"""

module_name = "ipecharts"
module_version = "^1.0.0"
